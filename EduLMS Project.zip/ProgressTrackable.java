package Javawithoops;

interface ProgressTrackable{		//interface is used-full abstraction
	void trackProgress();
}

